# PHP-receipt-generator
<br>
A simple Receipt generator for an online store or store with computerised reciept. It take data from user such as details of customer and details of products.
<br>
It can also be modified to take the details from a database
<br>
The generated Reciept is ready for download
<br>
<br>
<b>Technologies Used : </b>
HTML, CSS, Bootstrap, Javascript, Object Oriented PHP, FPDF
<br><br>
<b>About FPDF : </b>
FPDF is a PHP class which allows to generate PDF files with pure PHP, that is to say without using the PDFlib library
